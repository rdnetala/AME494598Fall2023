var mongo = require('../');

exports.db = mongo.db('mongodb://localhost/test');
